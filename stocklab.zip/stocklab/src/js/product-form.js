const stateFor = (stock) => {
  if (stock === 0) return 'agotado';
  if (stock < 10) return 'bajo';
  return 'disponible';
};

function createRow({ sku, nombre, categoria, stock }) {
  const template = document.querySelector('#rowTemplate');
  const row = template.content.cloneNode(true);

  const numericStock = Number(stock);
  const estado = stateFor(numericStock);

  Object.entries({
    sku,
    nombre,
    categoria,
    stock: numericStock
  }).forEach(([field, value]) => {
    row.querySelector(`[data-field="${field}"]`).textContent = value;
  });

  const badge = row.querySelector('.status-badge');

  badge.classList.add(`status-badge--${estado}`);
  badge.textContent = estado.charAt(0).toUpperCase() + estado.slice(1);

  return row;
}

function updateLowStock() {
  const rows = document.querySelectorAll('#productTable tbody tr');

  const lowStock = [...rows].filter((row) => {
    const stock = Number(row.querySelector('[data-field="stock"]')?.textContent);
    return stock > 0 && stock < 10;
  }).length;

  const counter = document.querySelector('#lowStockCount');

  if (counter) {
    counter.textContent = lowStock;
  }
}

export function initProductForm({ Modal, Toast }) {
  const form = document.querySelector('#productForm');
  const modalElement = document.querySelector('#productModal');
  const toastElement = document.querySelector('#saveToast');
  const tbody = document.querySelector('#productTable tbody');

  if (!form || !modalElement || !toastElement || !tbody) return;

  const modal = Modal.getOrCreateInstance(modalElement);
  const toast = Toast.getOrCreateInstance(toastElement);

  form.addEventListener('submit', (event) => {
    event.preventDefault();

    if (!form.checkValidity()) {
      form.classList.add('was-validated');
      form.querySelector(':invalid')?.focus();
      return;
    }

    const data = Object.fromEntries(new FormData(form));

    const duplicate = [...tbody.querySelectorAll('tr')].some((row) => {
      return row.cells[0].textContent.trim() === data.sku.trim();
    });

    if (duplicate) {
      const skuInput = form.querySelector('#sku');
      skuInput.setCustomValidity('Este SKU ya existe.');
      skuInput.reportValidity();
      skuInput.focus();
      return;
    }

    form.querySelector('#sku').setCustomValidity('');

    tbody.prepend(createRow(data));

    form.reset();
    form.classList.remove('was-validated');

    updateLowStock();

    modal.hide();
    toast.show();

    // Actualizar el buscador después de insertar el producto.
    document.querySelector('#productSearch')?.dispatchEvent(
      new Event('input', { bubbles: true })
    );
  });

  form.querySelector('#sku')?.addEventListener('input', (event) => {
    event.target.setCustomValidity('');
  });

  updateLowStock();
}