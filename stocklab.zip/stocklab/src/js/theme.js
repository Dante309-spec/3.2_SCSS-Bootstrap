const STORAGE_KEY = 'stocklab-theme';
const root = document.documentElement;

const themes = ['light', 'dark', 'contrast'];

function applyTheme(theme) {
  const selectedTheme = themes.includes(theme) ? theme : 'light';

  root.dataset.bsTheme =
    selectedTheme === 'contrast' ? 'dark' : selectedTheme;

  root.dataset.stocklabTheme = selectedTheme;

  const button = document.querySelector('#themeToggle');

  if (button) {
    button.setAttribute(
      'aria-pressed',
      String(selectedTheme !== 'light')
    );

    button.setAttribute(
      'aria-label',
      `Tema actual: ${selectedTheme}. Cambiar tema`
    );

    button.setAttribute(
      'title',
      `Tema actual: ${selectedTheme}`
    );
  }
}

export function initThemeToggle() {
  let savedTheme = 'light';

  try {
    savedTheme = localStorage.getItem(STORAGE_KEY) || root.dataset.bsTheme || 'light';
  } catch {
    savedTheme = root.dataset.bsTheme || 'light';
  }

  applyTheme(savedTheme);

  document.querySelector('#themeToggle')?.addEventListener('click', () => {
    const currentTheme = root.dataset.stocklabTheme || 'light';
    const currentIndex = themes.indexOf(currentTheme);
    const nextTheme = themes[(currentIndex + 1) % themes.length];

    try {
      localStorage.setItem(STORAGE_KEY, nextTheme);
    } catch {
      // El tema seguirá funcionando aunque no se pueda guardar.
    }

    applyTheme(nextTheme);
  });
}