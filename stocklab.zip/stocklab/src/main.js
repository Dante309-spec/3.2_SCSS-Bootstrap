import './scss/main.scss';

import {
  Modal,
  Offcanvas,
  Toast,
  Tooltip
} from 'bootstrap';

import { initThemeToggle } from './js/theme.js';
import { initProductForm } from './js/product-form.js';

// Inicializar el cambio de tema
initThemeToggle();

// Inicializar tooltips de Bootstrap
document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach((el) => {
  new Tooltip(el);
});

// Inicializar el formulario de productos
initProductForm({ Modal, Toast });

// Reto 3: Sidebar compacto
const sidebarToggle = document.querySelector('#sidebarToggle');
const appShell = document.querySelector('.app-shell');

if (sidebarToggle && appShell) {
  sidebarToggle.addEventListener('click', () => {
    const isCompact = appShell.classList.toggle('app-shell--compact');

    sidebarToggle.setAttribute('aria-expanded', String(!isCompact));

    sidebarToggle.setAttribute(
      'aria-label',
      isCompact ? 'Expandir menú' : 'Contraer menú'
    );

    sidebarToggle.setAttribute(
      'title',
      isCompact ? 'Expandir menú' : 'Contraer menú'
    );
  });
}

// Reto 6: búsqueda dinámica por SKU o nombre
const productSearch = document.querySelector('#productSearch');
const productTableBody = document.querySelector('#productTable tbody');
const noResults = document.querySelector('#noResults');

if (productSearch && productTableBody) {
  productSearch.addEventListener('input', () => {
    const query = productSearch.value.trim().toLocaleLowerCase('es');

    const rows = [...productTableBody.querySelectorAll('tr')];
    let visibleRows = 0;

    rows.forEach((row) => {
      const sku = row.cells[0].textContent.toLocaleLowerCase('es');
      const name = row.cells[1].textContent.toLocaleLowerCase('es');

      const matches = sku.includes(query) || name.includes(query);

      row.hidden = !matches;

      if (matches) {
        visibleRows++;
      }
    });

    if (noResults) {
      noResults.hidden = visibleRows !== 0;
    }
  });
}