import './scss/main.scss';
import { Offcanvas, Tooltip } from 'bootstrap';
import { initThemeToggle } from './js/theme.js';

initThemeToggle();

document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach((el) => {
  new Tooltip(el);
})